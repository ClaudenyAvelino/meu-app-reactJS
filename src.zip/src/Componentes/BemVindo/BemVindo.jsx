import './BemVindo.css';

function BemVindo() {

  return <h1 className="titulo-bemvindo">Seja bem-vindo(a)</h1>;
}

export default BemVindo;