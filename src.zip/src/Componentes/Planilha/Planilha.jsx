import { useEffect, useState } from "react";
import "./Planilha.css"; 
function Planilha() {
  const [dados, setDados] = useState([]);

  useEffect(() => {
    // Substitua pelo link CSV da sua planilha publicada:
    const URL =
      "https://docs.google.com/spreadsheets/d/e/2PACX-1vQRJtbSgNEmjq7rXZQEeY-9diILR-YX_hDC83V6AoBV4rH_qC7LFT-pLmRy7znZeU3oi5uJcJTJIBAH/pub?output=csv";

    fetch(URL)
      .then((res) => res.text())
      .then((csvText) => {
        const linhas = csvText.split("\n").map((linha) => linha.split(","));
        const cabecalho = linhas[0];
        const linhasDados = linhas.slice(1);

        const objetos = linhasDados.map((linha) => {
          let obj = {};
          cabecalho.forEach((col, i) => (obj[col.trim()] = linha[i]));
          return obj;
        });

        setDados(objetos);
      })
      .catch((err) => console.error("Erro ao carregar planilha:", err));
  }, []);

  return (
    <div className="planilha-container">
      <h2>Dados da Planilha</h2>
      <table className="planilha-tabela">
        <thead>
          <tr>
            {dados[0] &&
              Object.keys(dados[0]).map((coluna) => (
                <th key={coluna}>{coluna}</th>
              ))}
          </tr>
        </thead>
        <tbody>
          {dados.map((linha, idx) => (
            <tr key={idx}>
              {Object.values(linha).map((valor, i) => (
                <td key={i}>{valor}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Planilha;