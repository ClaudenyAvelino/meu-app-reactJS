import Banner from './Componentes/Banner/Banner';
import BemVindo from './Componentes/BemVindo/BemVindo';
import Saudacao from './Componentes/Saudacao/Saudacao';
import Planilha from './Componentes/Planilha/Planilha';
import './App.css';

function App() {
  return (
    <div className="App">
      <Banner />
      <main className="conteudo-principal">
        <BemVindo />
        <Saudacao />
        <Planilha />
      </main>
    </div>
  );
}

export default App;